#include "graph.h"

void cycle_detection(graph *g) {

}
