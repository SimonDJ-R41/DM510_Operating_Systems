#include <stdlib.h>
#include "graph.h"


graph *read_graph(char *filename) {
	return NULL;
}

void print_graph(graph *g) {

}

