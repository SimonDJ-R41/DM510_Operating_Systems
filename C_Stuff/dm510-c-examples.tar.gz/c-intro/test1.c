#include <stdio.h>
#include <stdlib.h>

int main(int argc, char** argv)
{
  char *s = "Hello";
  int i[] = {3,6,8,9};
  int j=1000;
  int *p = calloc(10,sizeof(int));
  p[3]=42;
  printf("Value: %d\n",(char)(128));
  return 0; 
}
