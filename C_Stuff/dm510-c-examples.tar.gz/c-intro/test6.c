#include <stdio.h>

int main(int argc, char** argv)
{
  int *x;
  x++;

  int y[0];
  y++;
}
