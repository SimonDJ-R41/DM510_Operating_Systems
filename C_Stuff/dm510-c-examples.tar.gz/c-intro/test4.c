#include <stdio.h>

int main(int argc, char** argv)
{
  printf("Value: %d\n",(42==42));
  return 0; 
}
